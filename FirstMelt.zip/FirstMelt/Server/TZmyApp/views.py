from django.shortcuts import render
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from django.http import HttpResponse
import quandl
import os

from datetime import datetime
from datetime import timedelta
from TZmyApp import models

import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
import base64
from io import BytesIO

import json

from TZmyApp.AnalystProject.strategies import Strategies

def multiChart(data,symbol):
    plt.title(symbol)
    data.plot(title = symbol, grid = True)
    buffer = BytesIO()
    plt.savefig(buffer)
    plot_data = buffer.getvalue()
    return plot_data

def LoadDataFrame(filename):
    df = pd.DataFrame()

    if os.path.isfile(filename):
        df = pd.read_csv(filepath_or_buffer=filename)
        df['<date>'] = df['<date>'].astype(str)

    return df

def LoadQuandl(start,end,product_type,symbol):
    dfs = pd.DataFrame()
    quandl.ApiConfig.api_key = 'zizZiVmuPxTXufiSUffd'
    if product_type == "Stock":
        df = quandl.get("WIKI/"+str(symbol), trim_start=start, trim_end=end)
    elif product_type == "FX":
        df = quandl.get("CUR/"+str(symbol), trim_start=start, trim_end=end)
        df = df.rename(columns = {"RATE":"Close"})

    elif product_type == "Future":
        df = quandl.get("SRF/"+str(symbol), trim_start=start, trim_end=end)
        df = df.rename(columns = {"Settle":"Close"})
    return df

# not being used
def LoadAllDataFrames(start, end,product_type):
    dfs = pd.DataFrame()

    dt_range = end - start

    for i in range(0, dt_range.days + 1):

        dt = start + timedelta(i)
        if(product_type == 'FX'):

            filename = "/Users/ningxu/Desktop/AnalystProject/BackTesting/TestData/FOREX_2011/FOREX_" + dt.strftime('%Y%m%d') + ".txt"
        else:
            filename = "/Users/ningxu/Desktop/AnalystProject/BackTesting/TestData/NASDAQ_2011/NASDAQ_" + dt.strftime('%Y%m%d') + ".txt"
        df = LoadDataFrame(filename)

        if not df.empty:
            dfs = pd.concat([dfs, df])

    return dfs
def pat_backTest(df3,short_term,long_term):
    df_Res = pd.DataFrame()
    # df_Res['Date'] = df2['<date>']
    df_Res['short_term'] = np.round(short_term, 2)
    df_Res['long_term'] = np.round(long_term, 2)
    df_Res['Diff'] = df_Res['short_term'] - df_Res['long_term']
    df_Res['Regime'] = np.where(df_Res['Diff'] / df_Res['long_term'] > 0.001, 1, 0)
    df_Res['Regime'] = np.where(df_Res['Diff'] / df_Res['long_term'] < -0.01, -1, df_Res['Regime'])
    df_Res['Market'] = np.log(df3['Close'] / df3['Close'].shift(1))
    df_Res['Strategy'] = df_Res['Regime'].shift(1) * df_Res['Market']
    return df_Res

def test_quandl(request):
    if request.method == 'POST':
        type1 = str(request.POST.get('type'))
        product = str(request.POST.get('product'))
        fro = str(request.POST.get('from'))
        to = str(request.POST.get('to'))
        APPL_quandl = LoadQuandl(fro,to,type1,product)

        indexlist = pd.DataFrame(APPL_quandl.index.values)
        indexlist = indexlist.rename(columns = {0:"Date"})
        indexlist['Date'] = indexlist['Date'].dt.strftime('%Y-%m-%d')
        
        print (indexlist.dtypes)

        
        
        short = 10
        long = 60
        short_term = APPL_quandl['Close'].ewm(span=short).mean()
        long_term = APPL_quandl['Close'].ewm(span=long).mean()
        df_Res = pat_backTest(APPL_quandl, short_term, long_term)
        for line in df_Res:
            ls = []
            for j in line:
                ls.append(j)
            df_Res.append(ls)
        ar = np.array(df_Res)
        cols = ['Market', 'Strategy']
        
        datat = df_Res[cols].cumsum().apply(np.exp).reset_index()

        datat1 = pd.concat([indexlist,datat[cols]], axis=1)

        datat1.to_json(r'/Users/ningxu/Desktop/AnalystProject/mmmm_quandl.json', orient="split")
        return render(request, "index.html", { "test_data": ar})
    else:
        return render(request, "index.html")


def test(request):
    if request.method == 'POST':
        type1 = str(request.POST.get('type'))
        #print('**********************\n',year_from)
        product = str(request.POST.get('product'))
        fro = str(request.POST.get('from'))
        fro1 = fro.split('-')
        yr_from = int(fro1[0])
        mn_from = int(fro1[1])
        day_from= int(fro1[2])
        to = str(request.POST.get('to'))
        to1 = to.split('-')
        yr_to = int(to1[0])
        mn_to = int(to1[1])
        day_to = int(to1[2])
        start = datetime(yr_from, mn_from, day_from)
        end = datetime(yr_to, mn_to, day_to)
        symbol = product
        df2 = LoadAllDataFrames(start, end,type1)
        date1 = df2['<date>'].unique()
        date1 = pd.DataFrame(date1)
        #date1.to_json(r'E:/H/citi/training/BackTesting/Back Testing/date.json', orient="split")
        df2 = df2.set_index(['<ticker>'])
        df3 = df2.xs(symbol)
        short = 10
        long = 60
        short_term = df3['<close>'].ewm(span=short).mean()
        long_term = df3['<close>'].ewm(span=long).mean()
        df_Res = pat_backTest(df3, short_term, long_term)
        for line in df_Res:
            ls = []
            for j in line:
                ls.append(j)
            df_Res.append(ls)
        ar = np.array(df_Res)
        cols = ['Market', 'Strategy']
        datat = df_Res[cols].cumsum().apply(np.exp).reset_index()
        datat1 = pd.concat([date1,datat], axis=1)
        print(datat1)
        datat1.to_json(r'E:/H/citi/training/BackTesting/Back Testing/mmmm_local.json',orient="split")
        return render(request, "index.html", { "test_data": ar})
    else:
        return render(request, "index.html")

def index(request):

    if request.method == 'POST':
        year_from = int(str(request.POST.get('year_from')))
        #print('**********************\n',year_from)
        month_from = int(str(request.POST.get('month_from')))
        day_from = int(str(request.POST.get('day_from')))
        year_to = int(str(request.POST.get('year_t')))
        month_to = int(str(request.POST.get('month_t')))
        day_to = int(str(request.POST.get('day_t')))
        code = str(request.POST.get('Code'))
        print("***********:",code)
        start = datetime(year_from,month_from,day_from)
        end = datetime(year_to,month_to,day_to)
        symbol = code
        df2 = LoadAllDataFrames(start, end)
        df2 = df2.set_index(['<ticker>'])
        df3 = df2.xs(symbol)
        short = 10
        long = 60
        short_term = df3['<close>'].ewm(span=short).mean()
        long_term = df3['<close>'].ewm(span=long).mean()
        df_Res = pd.DataFrame()
        df_Res['short_term'] = np.round(short_term, 2)
        df_Res['long_term'] = np.round(long_term, 2)
        df_Res['Diff'] = df_Res['short_term'] - df_Res['long_term']
        df_Res['Regime'] = np.where(df_Res['Diff']/df_Res['long_term'] > 0.001, 1, 0)
        df_Res['Regime'] = np.where(df_Res['Diff'] / df_Res['long_term'] < -0.01, -1, df_Res['Regime'])
        df_Res['Market'] = np.log(df3['<close>'] / df3['<close>'].shift(1))
        df_Res['Strategy'] = df_Res['Regime'].shift(1) * df_Res['Market']
        for line in df_Res:
            ls=[]
            for j in line:
                ls.append(j)
            df_Res.append(ls)
        ar = np.array(df_Res)
        cols = ['Market', 'Strategy']
        datat = df_Res[cols].cumsum().apply(np.exp)
        plot_data1=multiChart(datat,symbol)
        imb1 = base64.b64encode(plot_data1)  # 对plot_data进行编码
        ims1 = imb1.decode()
        imd1 = "data:image/png;base64," + ims1
        return render(request, "index.html", {"img": imd1, "test_data": ar})
    else:
        return render(request, "index.html")


def linkStra(request):
    if request.method == 'POST':
        product_type = str(request.POST.get('type'))
        code = str(request.POST.get('product'))
        start = str(request.POST.get('from'))
        end = str(request.POST.get('to'))

        allcode = ''

        if product_type == 'Stock':
            allcode = "WIKI/"+str(code)
            print (allcode)
        elif product_type == 'FX':
            allcode = "CUR/"+str(code)

        df,crossdict,BHdict = Strategies([allcode],start,end)

        indexlist = pd.DataFrame(df.index.values)
        indexlist = indexlist.rename(columns = {0:"Date"})
        indexlist['Date'] = indexlist['Date'].dt.strftime('%Y-%m-%d')
        
        #col buy and sell-basicMarketStrategy
        #crossover
        cols = ['buy and sell-basicMarketStrategy','crossover']
        data = df[cols].reset_index()

        datat1 = pd.concat([indexlist,data[cols]], axis=1)

        

        CDjson = json.dumps(crossdict)
        BHjson = json.dumps(BHdict)

        print (CDjson)
        print (BHjson)
      
        datat1.to_json(r'/Users/ningxu/Desktop/AnalystProject/mmmm_quandl.json',orient="split")

        f = open("/Users/ningxu/Desktop/AnalystProject/mmmm_quandl.json", "a")

        f.write('\n'+CDjson+'\n'+BHjson)
        f.close()


        return render(request, "index.html")
    
    else:
        return render(request, "index.html")
