import os
from TZmyApp.AnalystProject.quant.engine.trading_env import TradingEnv
from TZmyApp.AnalystProject.quant.engine.datafeed import DataFeed
from TZmyApp.AnalystProject.quant.engine.algos import *

def Strategies(stock_code,start,end):
    path = os.path.abspath(os.path.join(os.getcwd(), "quant/data"))
    feed = DataFeed(data_path=path)
    # feed.load_stock_csv(["WIKI/C","WIKI/AAPL"], "2012-12-12","2013-03-17")
    feed.load_stock_csv(stock_code, start,end)

   #THIS IS REGARDED AS THE MARKET PAYOFF
    buy_and_hold = Strategy([
        RunOnce(),
        PrintBar(),
        SelectAll(),
        WeighEqually(),
    ], name='buy and sell-basicMarketStrategy')

    #THIS IS THE STRATEGY USING MACD
    long_expr = 'cross_up(ma(close,5),ma(close,10))'
    flat_expr = 'cross_down(ma(close,5),ma(close,10))'
    ma_cross = Strategy([
        SelectByExpr(long_expr=long_expr, flat_expr=flat_expr),
        WeighEqually(),
    ], name='crossover')

    env_benchmark = TradingEnv(strategy=buy_and_hold, feed=feed)
    env_benchmark.run_strategy()

    env = TradingEnv(strategy=ma_cross, feed=feed)
    env.run_strategy()

    bench_stats = env_benchmark.get_statistics()
    stra_stats = env.get_statistics()

    stats = [bench_stats, stra_stats]

    from TZmyApp.AnalystProject.quant.engine.trading_env import EnvUtils

    utils = EnvUtils(stats=stats)
    df = utils.show_stats()
    return df

# if __name__ == '__main__':
#     stock_code = ["WIKI/C","WIKI/AAPL"]
#     start = "2012-12-12"
#     end = "2013-03-17"
#     main(stock_code,start,end)
