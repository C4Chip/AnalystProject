from AnalystProject.strategies import Strategies

Strategies(["WIKI/C","WIKI/AAPL"], "2012-12-12","2013-03-17")