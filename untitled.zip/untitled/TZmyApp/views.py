from django.shortcuts import render
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from django.http import HttpResponse

import os

from datetime import datetime
from datetime import timedelta
from TZmyApp import models

import matplotlib.pyplot as plt

import pandas as pd
import numpy as np
import base64
from io import BytesIO

def multiChart(data,code):
    plt.title(code)
    data.plot(title=code,grid=True)
    buffer = BytesIO()
    plt.savefig(buffer)
    plot_data = buffer.getvalue()
    return plot_data


def LoadDataFrame(filename):
    df = pd.DataFrame()

    if os.path.isfile(filename):
        df = pd.read_csv(filepath_or_buffer=filename)
        df['<date>'] = df['<date>'].astype(str)

    return df


def LoadAllDataFrames(start, end,productType):
    dfs = pd.DataFrame()

    dt_range = end - start

    for i in range(0, dt_range.days + 1):

        dt = start + timedelta(i)

        if (productType == 'FX'):
            filename = "/Users/ningxu/Desktop/AnalystProject/BackTesting/TestData/FOREX_2011/FOREX_" + dt.strftime('%Y%m%d') + ".txt"
        else:
            filename = "/Users/ningxu/Desktop/AnalystProject/BackTesting/TestData/NASDAQ_2011/NASDAQ_" + dt.strftime('%Y%m%d') + ".txt"

        df = LoadDataFrame(filename)

        if not df.empty:
            dfs = pd.concat([dfs, df])

    return dfs




def index(request):

    if (request.method == 'POST'):
        year_from = int(str(request.POST.get('year_f')))
        month_from = int(str(request.POST.get('month_f')))
        day_from = int(str(request.POST.get('day_f')))
        year_to = int(str(request.POST.get('year_t')))
        month_to = int(str(request.POST.get('month_t')))
        day_to = int(str(request.POST.get('day_t')))

        productType = str(request.POST.get('types'))

        code = str(request.POST.get('Code'))


        start = datetime(year_from,month_from,day_from)
        end = datetime(year_from,month_to,day_to)
        #symbol = "AAPL"
        df2 = LoadAllDataFrames( start, end, productType)
        df2 = df2.set_index(['<ticker>'])
        df3 = df2.xs(code)
        short = 10
        long = 60
        short_term = df3['<close>'].ewm(span=short).mean()
        long_term = df3['<close>'].ewm(span=long).mean()
        df_Res = pd.DataFrame()
        df_Res['short_term'] = np.round(short_term, 2)
        df_Res['long_term'] = np.round(long_term, 2)
        df_Res['Diff'] = df_Res['short_term'] - df_Res['long_term']
        df_Res['Regime'] = np.where(df_Res['Diff']/df_Res['long_term'] > 0.001, 1, 0)
        df_Res['Regime'] = np.where(df_Res['Diff'] / df_Res['long_term'] < -0.01, -1, df_Res['Regime'])
        df_Res['Market'] = np.log(df3['<close>'] / df3['<close>'].shift(1))
        df_Res['Strategy'] = df_Res['Regime'].shift(1) * df_Res['Market']
        for line in df_Res:
            ls=[]
            for j in line:
                ls.append(j)
            df_Res.append(ls)
        ar = np.array(df_Res)
        cols = ['Market', 'Strategy']
        datat = df_Res[cols].cumsum().apply(np.exp)
        plot_data1=multiChart(datat,code)
        imb1 = base64.b64encode(plot_data1)  # 对plot_data进行编码
        ims1 = imb1.decode()
        imd1 = "data:image/png;base64," + ims1
        return render(request, "index.html", {"img": imd1, "test_data": ar})
    else:
        return render(request, "index.html")
