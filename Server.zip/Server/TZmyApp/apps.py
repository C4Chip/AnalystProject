from django.apps import AppConfig


class TzmyappConfig(AppConfig):
    name = 'TZmyApp'
