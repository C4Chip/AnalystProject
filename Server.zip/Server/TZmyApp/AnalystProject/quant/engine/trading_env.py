

from .portfolio import Portfolio
from .common.logging_utils import logger
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def maxdrawdown(return_list):
    #print(np.maximum.accumulate(return_list))
    for i in range(0, len(return_list)):
        if return_list[i] == 0:
            return_list[i] = 10000000

    i = np.argmax((np.maximum.accumulate(return_list) - return_list) / np.maximum.accumulate(return_list))  # 结束位置

    if i == 0:
        return 0
    j = np.argmax(return_list[:i])  # 开始位置
    if return_list[j] ==0:
        pass
    else:
        return (return_list[j] - return_list[i]) / (return_list[j])

class TradingEnv(object):
    def __init__(self,strategy,feed,init_cash=100000.0):
        self.feed = feed
        self.strategy = strategy
        self.init_cash = init_cash
        self.all_close = feed.get_close_from_feed()

        self.portfolio = Portfolio(data=self.all_close,init_cash=init_cash)
        self.__init_env()

    def get_statistics(self):
        df,all = self.portfolio.statistics()
        
        period_returns = df['equity'][-1] - 1
        num_years = self.context['len'] / 252
        annual_returns = (1 + period_returns) ** (1 / num_years) - 1

        #from empyrical import stats

        returns = df['returns']
        volatility = returns.std() * (252 ** 0.5)
        
        sharpe = (returns.mean() / returns.std()) * (252 ** 0.5)
        #print(returns.isnull())
        return1 = returns.dropna().values
        #print(return1)

        # sharpe
        #returns1 = return1.dropna()
      # print(str(type(return1)))
        #print(returns)
        #sharpe = stats.sharpe_ratio(returns)
        # Max drawdown
        max_drawdown = maxdrawdown(return1)

        return {
            'name':self.strategy.name,
            'period_returns':period_returns,
            'annual_returns':annual_returns,
            'volatility':volatility,
            'sharpe':sharpe,
            'max_drawdown':max_drawdown,
            'equity':df['equity'],
            'returns':returns
        }

    # def plot(self):
    #     import matplotlib.pyplot as plt
    #     import matplotlib
    #     ret = self.get_statistics()
    #     ret['equity'].plot(title='buyandhold：netvaluecurve', legend=True, grid=True)



    def __init_env(self):
        self.context = {'universe': self.all_close.columns,
                        'total': self.init_cash,
                        'cash': self.init_cash,
                        'all_close':self.all_close,
                        'all_data':self.feed.data,
                        'max_hold': 10,  # 最大持仓数，默认为10支
                        'idx': -1,
                        'now': None,
                        'len':len(self.all_close)
                        }
        logger.info('backtesting from{}to{},totally{}period'.format(self.all_close.index[0],self.all_close.index[-1],len(self.all_close)))
        to_file = ('backtesting from{}to{},totally{}period'.format(self.all_close.index[0],self.all_close.index[-1],len(self.all_close)))

        f = open("/Users/ningxu/Desktop/AnalystProject/log.txt", "a")
        f.write(to_file+'\n')
        f.close


    def __update_env(self):
        self.context['idx'] = self.portfolio.idx
        self.context['now'] = self.portfolio.now
        self.context['bar'] = self.all_close.iloc[self.context['idx']]

    def run_strategy(self):
        done = False
        observation = None
        while not done:
            observation,reward,done,info = self.run_step()
        logger.info('backtesting is success！')
        to_file = ('backtesting is success！')

        f = open("/Users/ningxu/Desktop/AnalystProject/log.txt", "a")
        f.write(to_file+'\n')
        f.close

    #环境运行一步
    def run_step(self):
        '''
        :param actions: 交易指令 {LONG:['AAPL',],FLAT:['BTC']}表示买入AAPL,卖出BTC
        :return: observation,reward,done,info
        '''

        done = self.portfolio.update()
        self.__update_env()
        # 这里strategy会修改env.context
        self.strategy(self.context)
        self.portfolio.step(self.context)


        observation = None
        reward = None
        info = None
        return observation,reward,done,info

class EnvUtils(object):
    def __init__(self,stats):
        self.stats =  stats

    def show_stats(self):
        dfs = []
        crossdict = {}
        BHdict = {}
        second = {}

        i = 0
        for stat in self.stats:
            print('{}BackTesting Result:'.format(stat['name']))
            print('Return:{},Annual Return:{}'.format(stat['period_returns'], stat['annual_returns']))
            print('Volitility：{}'.format(stat['volatility']))
            print('Sharpe Ratio：{}'.format(stat['sharpe']))
            print('Maximum Drawdown：{}'.format(stat['max_drawdown']))
            equity = stat['equity']
            equity.name = stat['name']
            df_item = equity
            dfs.append(df_item)
            alph = stat['Alpha']

            if i==0:
                keys = ['BackTesting','Return','Annual Return','Volitility','Sharpe Ratio','Maximum Drawdown','Alpha','Beta']
                values = [stat['name'], stat['period_returns'], stat['annual_returns'],stat['volatility'],stat['sharpe'],stat['max_drawdown'],stat['Alpha'],stat['Beta']]
                crossdict = dict(zip(keys,values))
                i = 1 + i
            elif i==1:
                keys = ['BackTesting','Return','Annual Return','Volitility','Sharpe Ratio','Maximum Drawdown','Alpha','Beta']
                values = [stat['name'], stat['period_returns'], stat['annual_returns'],stat['volatility'],stat['sharpe'],stat['max_drawdown'],stat['Alpha'],stat['Beta']]
                second = dict(zip(keys,values))
                i = i+1
            elif i==2:
                keys = ['BackTesting','Return','Annual Return','Volitility','Sharpe Ratio','Maximum Drawdown','Alpha','Beta']
                values = [stat['name'], stat['period_returns'], stat['annual_returns'],stat['volatility'],stat['sharpe'],stat['max_drawdown'],stat['Alpha'],stat['Beta']]
                BHdict = dict(zip(keys,values))

            


        all = pd.concat(dfs,axis=1)
        
        return all,crossdict,BHdict,second

        # import matplotlib.pyplot as plt
        # import matplotlib

        # from pylab import mpl
        # mpl.rcParams['font.sans-serif'] = ['FangSong']  # 指定默认字体
        # mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题
        # plt.show()
