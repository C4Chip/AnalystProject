import os
from TZmyApp.AnalystProject.quant.engine.trading_env import TradingEnv
from TZmyApp.AnalystProject.quant.engine.datafeed import DataFeed
from TZmyApp.AnalystProject.quant.engine.algos import *
import statsmodels.api as sm
from statsmodels import regression


def Strategies(stock_code,start,end,Indicator,Type):
    # path = os.path.abspath(os.path.join(os.getcwd(), "quant/data"))
    # feed = DataFeed(data_path=path)
    # # feed.load_stock_csv(["WIKI/C","WIKI/AAPL"], "2012-12-12","2013-03-17")
    # alldata = feed.load_stock_csv(stock_code, start,end)

    #15 aug
    if Type == 'Stock':
        path = os.path.abspath(os.path.join(os.getcwd(), "quant/data"))
        feed = DataFeed(data_path=path)
    # feed.load_stock_csv(["WIKI/C","WIKI/AAPL"], "2012-12-12","2013-03-17")
        feed.load_stock_csv(stock_code, start, end)
    elif Type == 'FX':
        path = os.path.abspath(os.path.join(os.getcwd(), "quant/data"))
        feed = DataFeed(data_path=path)
        feed.load_fx_csv(stock_code, start, end)
    elif Type == 'Index':
        path = os.path.abspath(os.path.join(os.getcwd(), "quant/data/"))
        feed = DataFeed(data_path=path)
        feed.load_idx_csv(stock_code, start, end)
    elif Type == 'Future':
        path = os.path.abspath(os.path.join(os.getcwd(), "quant/data"))
        feed = DataFeed(data_path=path)
        feed.load_fut_csv(stock_code, start, end)
    else:
        print("The type is not available")

   #THIS IS REGARDED AS THE MARKET PAYOFF
    buy_and_hold = Strategy([
        RunOnce(),
        PrintBar(),
        SelectAll(),
        WeighEqually(),
    ], name='buy and sell-basicMarketStrategy')

    # New from Pan
    long_expr = 'cross_up(ma(close,5),ma(close,10))'
    flat_expr = 'cross_down(ma(close,5),ma(close,10))'
    ma_cross = Strategy([
        SelectByExpr(long_expr=long_expr, flat_expr=flat_expr),
        WeighEqually(),
    ], name='ma_cross')
    # add...
    # THIS IS THE STRATEGY USING ema
    window_size = '26'
    long_expr_ema = 'cross_up(ema(close,5),ema(close,'+window_size+'))'
    flat_expr_ema = 'cross_down(ema(close,5),ema(close,'+window_size+'))'
    ema_cross = Strategy([
        SelectByExpr(long_expr=long_expr_ema, flat_expr=flat_expr_ema),
        WeighEqually(),
    ], name='ema_cross')

    # THIS IS THE STRATEGY USING rsi
    
    long_expr_rsi = 'cross_up(rsi(close,5),rsi(close,'+window_size+'))'
    flat_expr_rsi = 'cross_down(rsi(close,5),rsi(close,'+window_size+'))'
    rsi_cross = Strategy([
        SelectByExpr(long_expr=long_expr_rsi, flat_expr=flat_expr_rsi),
        WeighEqually(),
    ], name='rsi_cross')

    # THIS IS THE STRATEGY USING obv
    long_expr_obv = 'cross_up(obv(close,5),obv(close,'+window_size+'))'
    flat_expr_obv = 'cross_down(obv(close,5),obv(close,'+window_size+'))'
    obv_cross = Strategy([
        SelectByExpr(long_expr=long_expr_obv, flat_expr=flat_expr_obv),
        WeighEqually(),
    ], name='obv_cross')

    # THIS IS THE STRATEGY USING mom
    long_expr_mom = 'cross_up(mom(close,5),mom(close,'+window_size+'))'
    flat_expr_mom = 'cross_down(mom(close,5),mom(close,'+window_size+'))'
    mom_cross = Strategy([
        SelectByExpr(long_expr=long_expr_mom, flat_expr=flat_expr_mom),
        WeighEqually(),
    ], name='mom_cross')

    # THIS IS THE STRATEGY USING macd
    long_expr_macd = 'cross_up(macd_n(close,'+window_size+',fast=12,signal=9),macd_sig(close,'+window_size+',fast=12,signal=9))'
    flat_expr_macd = 'cross_down(macd_n(close,'+window_size+',fast=12,signal=9),macd_sig(close,'+window_size+',fast=12,signal=9))'
    # long_expr_macd = 'cross_up(macd(close,fast=12,slow='+window_size+',signal=9)[2],macd(close,fast=12,slow='+window_size+',signal=9))[2]'
    # flat_expr_macd = 'cross_down(macd(close,fast=12,slow='+window_size+',signal=9)[2],macd(close,fast=12,slow='+window_size+',signal=9))[2]'
    macd_cross = Strategy([
        SelectByExpr(long_expr=long_expr_macd, flat_expr=flat_expr_macd),
        WeighEqually(),
    ], name='macd_cross')

    indices = {'buy_and_hold':buy_and_hold,'ma_cross':ma_cross,'ema_cross':ema_cross,'obv_cross':obv_cross,'rsi_cross':rsi_cross,'mom_cross':mom_cross,'macd_cross':macd_cross}

    env_benchmark = TradingEnv(strategy=buy_and_hold, feed=feed)
    env_benchmark.run_strategy()

    bench_stats = env_benchmark.get_statistics()
    bench_stats['Alpha'] = 0
    bench_stats['Beta'] = 1
    ret0 = pd.DataFrame(bench_stats['returns'],dtype =np.float)
    print(type(ret0))
    statis = [bench_stats]

    stra_stats = dict()

    for ind in Indicator:
    # statis= [bench_stats]
        if ind in indices.keys():
            env = TradingEnv(strategy=indices.get(ind), feed=feed)
            env.run_strategy()

            st = env.get_statistics()


            y = pd.DataFrame(st['returns'],dtype =np.float).dropna()
            print(type(y))
            ret0 = ret0.dropna()
            ret0 = sm.add_constant(ret0)
            print(y.head())
            print(ret0.head())
            print(y.info())
            # x1 = np.asarray(x)
            # ret1 = np.asarray(ret0)
            model = regression.linear_model.OLS(y,ret0).fit()
            print(model.params)
            st['Alpha'] = model.params[0]
            st['Beta'] = model.params[1]
            statis.append(st)

    # env = TradingEnv(strategy=ma_cross, feed=feed)
    # env.run_strategy()
    from TZmyApp.AnalystProject.quant.engine.trading_env import EnvUtils

    utils = EnvUtils(stats=statis)
    df = utils.show_stats()
    return df

# if __name__ == '__main__':
#     stock_code = ["WIKI/C","WIKI/AAPL"]
#     start = "2012-12-12"
#     end = "2013-03-17"
#     main(stock_code,start,end)
