 $(function () {
    var ticker ;
    $(".ui.dropdown").dropdown();
    $('#date1').calendar(
        {
           type:'date',
           formatter: {
            date: function(date, settings) {
                if (!date) return '';

                var year  = date.getFullYear();
                var month = date.getMonth() + 1;
                var day   = date.getDate();

                month = month < 10 ? '0'+month : month;
                day   = day   < 10 ? '0'+day   : day;

                return year + '-' + month + '-' + day;
          }
      }});

    $('#date2').calendar(
        {
            type:'date',
            formatter: {
                date: function(date, settings) {
                    if (!date) return '';

                    var year  = date.getFullYear();
                    var month = date.getMonth() + 1;
                    var day   = date.getDate();

                    month = month < 10 ? '0'+month : month;
                    day   = day   < 10 ? '0'+day   : day;

                    return year + '-' + month + '-' + day;
                }
             }
        });

    var strategy_arr = [];
    $('.strategy').on('change',function(){
        var one_strategy = $(this).find('option:selected').text();
        var selected_strategy = $('.selected-strategy');
        var newEle;
        var exist=false;
        if(strategy_arr.length==0)
        {
            newEle = $("<a class='ui label'>"+one_strategy+"<i class='delete icon'></i></a>");
            console.log(newEle);
            selected_strategy.append(newEle);
            strategy_arr.push(one_strategy);
        }else{
            if(strategy_arr.length>=3){
                alert("You can choice only three strategy");
            }else{
                for(var i=0; i<strategy_arr.length;i++){
                    if(strategy_arr[i]===one_strategy){
                        alert('You already choose this one');
                        exist=true;
                        break;
                    }
                }
                if(exist==false){
                    newEle = $("<a class='ui label'>"+one_strategy+"<i class='delete icon'></i></a>");
                    selected_strategy.append(newEle);
                    strategy_arr.push(one_strategy);

                }
            }
     }
    })

    var product_arr = [];
    $('.product-box').on('change',function(){
        var one_product = $(this).find('option:selected').text();
        var chosen_type = $('.type-box').find('option:selected').text();
        var selected_product = $('.selected-product');
        var newEle;
        var exist=false;
        console.log(chosen_type);
        if(chosen_type=='type'){
            alert("Please chose type first");
            console.log($(".product option[value='9']"));
            $(".product option[value='9']").attr("selected", "selected");
            return;
        }
        if(product_arr.length==0)
        {
            newEle = $("<a class='ui label'>"+one_product+"<i class='delete icon'></i></a>");
            selected_product.append(newEle);
            product_arr.push(one_product);
        }else{
            if(product_arr.length>=10){
                alert("You can choice only ten strategy");
            }else{
                for(var k=0; k<product_arr.length;k++){
                    if(product_arr[k]===one_product){
                        alert('You already choose this one');
                        exist=true;
                        break;
                    }
                }
                if(exist==false){
                    newEle = $("<a class='ui label'>"+one_product+"<i class='delete icon'></i></a>");
                    selected_product.append(newEle);
                    product_arr.push(one_product);

                }
            }
     }
    })



//    console.log("hello")
//    console.log($('.date-from').val());
//    $('.date-from').bind('input propertychange',function(){
//        console.log("hello");
//    })

     $('.date-from').on('change',function(){
            console.log($('.date-from').val());

     })

    $('.selected-strategy').on('click','.delete',function(){
        var parent =  $(this).parent();
        var grad_parent = $(this).parent().parent();
        delete_strategy = parent.text();
        console.log(delete_strategy);
        parent.remove();
        for(var i=0;i<strategy_arr.length;i++){
            if(strategy_arr[i]==delete_strategy){
                strategy_arr.splice(i,1);
            }
        }
    })

    $('.selected-product').on('click','.delete',function(){
        var parent =  $(this).parent();
        var grad_parent = $(this).parent().parent();
        delete_product = parent.text();
        console.log(delete_product);
        parent.remove();
        for(var i=0;i<product_arr.length;i++){
            if(product_arr[i]==delete_product ){
                product_arr.splice(i,1);
            }
        }
    })

    $('.window-size').on('change',function(){
        if(parseInt($(this).val())>60 ||parseInt($(this).val())<26){
            alert("Please input a number that is between 26 and 60");
            $(this).val(' ');
        }
    })

    $('.report').click(function(){

        type = $('.type').find("option:selected").text();
        product = $('.product').find("option:selected").text();
        indicator = $('.indicator').find("option:selected").text();
        from = $('.date-from').val();
        to = $('.date-to').val();
        console.log(type,product_arr,strategy_arr,from,to);
        // waiting for jason
        url = 'index/';
        $.post({
            'url':url,
            'datatype':"json",
            'traditional':true,
            'data':{'type':type,'product':product_arr,'indicator':strategy_arr,'from':from,'to':to},
            'success': function(data){
                console.log(data)
//              lineData = {"columns":["Date","buy and sell-basicMarketStrategy","crossover"],"index":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64],"data":[["2011-06-01",null,null],["2011-06-02",1.0089032114,1.0],["2011-06-03",1.0049462286,1.0],["2011-06-06",0.9609247944,1.0],["2011-06-07",0.9488065345,1.0],["2011-06-08",0.9297635545,1.0],["2011-06-09",0.9535054516,1.0],["2011-06-10",0.957215123,1.0],["2011-06-13",0.9881290515,1.0],["2011-06-14",0.9784839058,1.0],["2011-06-15",0.9591936144,1.0],["2011-06-16",0.9500430916,0.9992160626],["2011-06-17",0.9666129573,1.0166635139],["2011-06-20",0.9631505973,1.0130177778],["2011-06-21",0.9915914115,1.0429648958],["2011-06-22",0.99653764,1.0481730902],["2011-06-23",0.9940645257,1.045568993],["2011-06-24",0.9985161314,1.050256368],["2011-06-27",1.0084085885,1.0606727568],["2011-06-28",1.0123655714,1.0648393124],["2011-06-29",1.0457526141,1.0999946248],["2011-06-30",1.0492149741,1.1036403609],["2011-07-01",1.0798815912,1.1359311663],["2011-07-05",1.0722149369,1.127858465],["2011-07-06",1.058365497,1.1132755206],["2011-07-07",1.0736988055,1.1294209233],["2011-07-08",1.0588601198,1.11379634],["2011-07-11",1.00346236,1.0554645624],["2011-07-12",0.9856559372,1.0359011258],["2011-07-13",0.9955483943,1.0359011258],["2011-07-14",0.9844193801,1.0359011258],["2011-07-15",0.9685914487,1.0359011258],["2011-07-18",0.9527635173,1.0359011258],["2011-07-19",0.9596882373,1.0359011258],["2011-07-20",0.9745269229,1.0359011258],["2011-07-21",1.0165698657,1.0359011258],["2011-07-22",1.0150859971,1.0359011258],["2011-07-25",1.0064300971,1.0350892055],["2011-07-26",1.0016075243,1.0301304087],["2011-07-27",0.965871023,0.9933844528],["2011-07-28",0.9638925315,0.9913500746],["2011-07-29",0.9678505508,0.9946397118],["2011-08-01",0.9713138176,0.9946397118],["2011-08-02",0.9356916444,0.9946397118],["2011-08-03",0.9411339209,0.9946397118],["2011-08-04",0.8805267512,0.9946397118],["2011-08-05",0.8466362114,0.9946397118],["2011-08-08",0.710826676,0.9946397118],["2011-08-09",0.8065612665,0.9946397118],["2011-08-10",0.724184991,0.9946397118],["2011-08-11",0.7687127075,0.9946397118],["2011-08-12",0.7578281545,0.9946397118],["2011-08-15",0.7929555754,0.9946397118],["2011-08-16",0.7600545404,0.9946397118],["2011-08-17",0.7578281545,0.9946397118],["2011-08-18",0.7115688046,0.9946397118],["2011-08-19",0.6816362841,0.9946397118],["2011-08-22",0.6640725737,0.9946397118],["2011-08-23",0.6952419752,0.9946397118],["2011-08-24",0.7231954861,0.9946397118],["2011-08-25",0.7573334021,0.9946397118],["2011-08-26",0.7575807783,0.9946397118],["2011-08-29",0.7934503278,0.9938601443],["2011-08-30",0.7847921607,0.9829601524],["2011-08-31",0.7875132989,0.9863858641]]
// }

//               backtesting1 = {"BackTesting": "crossover", "Return": -0.025821258242068712, "Annual Return": -0.10744109826534232, "Volitility": 0.11771509833706648, "Sharpe Ratio": -0.9243262429557159, "Maximum Drawdown": 1.0000000027309914}
//               backtesting2 = {"BackTesting": "buy and sell-basicMarketStrategy", "Return": -0.19283003892584216, "Annual Return": -0.6057434408414801, "Volitility": 0.3931333607488897, "Sharpe Ratio": -2.2050409316861392, "Maximum Drawdown": 3.788314707535715}
//               candleData={"columns":["Date","Open","High","Low","Close"],"index":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64],"data":[["2011-06-01",40.99,41.0,39.59,39.65],["2011-06-02",39.7,40.34,39.1,40.01],["2011-06-03",39.5,40.3,39.45,39.85],["2011-06-06",39.55,39.6,37.9,38.07],["2011-06-07",38.45,38.6,37.54,37.58],["2011-06-08",37.37,38.0,36.76,36.81],["2011-06-09",36.87,37.98,36.8,37.77],["2011-06-10",37.61,38.32,36.84,37.92],["2011-06-13",38.06,39.48,37.87,39.17],["2011-06-14",39.51,39.55,38.66,38.78],["2011-06-15",38.38,38.83,37.3,38.0],["2011-06-16",37.7,38.34,37.01,37.63],["2011-06-17",38.01,38.47,37.87,38.3],["2011-06-20",37.95,38.72,37.81,38.16],["2011-06-21",38.26,39.38,38.0,39.31],["2011-06-22",39.21,40.17,39.02,39.51],["2011-06-23",38.93,39.46,38.58,39.41],["2011-06-24",39.44,39.71,38.96,39.59],["2011-06-27",39.44,40.2,39.43,39.99],["2011-06-28",40.16,40.32,39.76,40.15],["2011-06-29",41.01,41.53,40.68,41.5],["2011-06-30",41.59,42.0,41.21,41.64],["2011-07-01",41.53,43.06,41.42,42.88],["2011-07-05",42.89,43.0,42.21,42.57],["2011-07-06",42.15,42.22,41.37,42.01],["2011-07-07",42.37,42.96,42.31,42.63],["2011-07-08",42.08,42.25,41.83,42.03],["2011-07-11",41.28,41.4,39.57,39.79],["2011-07-12",39.48,40.02,39.02,39.07],["2011-07-13",39.44,40.22,39.11,39.47],["2011-07-14",39.72,39.87,39.0,39.02],["2011-07-15",40.14,40.39,38.12,38.38],["2011-07-18",38.2,38.25,36.92,37.74],["2011-07-19",37.83,38.18,37.421,38.02],["2011-07-20",38.17,39.12,38.04,38.62],["2011-07-21",39.14,40.38,39.06,40.32],["2011-07-22",40.27,40.5,39.84,40.26],["2011-07-25",39.69,40.06,39.4,39.91],["2011-07-26",39.76,40.09,39.4,39.715],["2011-07-27",39.39,39.415,38.01,38.27],["2011-07-28",38.24,38.87,38.1,38.18],["2011-07-29",37.92,38.77,37.64,38.34],["2011-08-01",39.34,39.38,37.92,38.48],["2011-08-02",38.25,38.5,37.03,37.04],["2011-08-03",37.05,37.46,36.42,37.26],["2011-08-04",36.61,36.99,34.75,34.81],["2011-08-05",34.97,35.5,31.81,33.44],["2011-08-08",31.55,32.42,26.25,27.95],["2011-08-09",29.43,32.9095,28.49,31.82],["2011-08-10",31.01,31.02,28.35,28.49],["2011-08-11",29.2,31.0,28.58,30.29],["2011-08-12",31.19,31.97,29.5,29.85],["2011-08-15",30.59,31.32,30.25,31.27],["2011-08-16",30.64,30.71,29.36,29.94],["2011-08-17",30.27,30.83,29.7,29.85],["2011-08-18",28.7,29.0,26.76,27.98],["2011-08-19",27.41,28.56,26.75,26.77],["2011-08-22",27.72,27.84,25.99,26.06],["2011-08-23",26.13,27.34,25.4,27.32],["2011-08-24",27.44,28.46,27.15,28.45],["2011-08-25",30.81,31.58,28.97,29.83],["2011-08-26",29.5,30.25,29.05,29.84],["2011-08-29",30.57,31.29,30.31,31.29],["2011-08-30",31.04,31.29,30.45,30.94],["2011-08-31",31.23,31.54,30.76,31.05]]}
              $.plotLine($.parseJSON(data.strategy_r));
              $.plotCandle($.parseJSON(data.open_close));
              $.plotTable([$.parseJSON(data.buy_and_hold),$.parseJSON(data.crossover_result),$.parseJSON(data.second)]); 

            }
        })

    })

    $.plotTable =  function(data){
        var tbody =  $('#table tbody');
        tbody.empty();
        data_arr=[];
        var td,tr;
        for(var i=0;i<data.length;i++){
            tr=$("<tr></tr>").addClass("center aligned");
            $.each(data[i],function(key){
                if(!isNaN(data[i][key]))
                {
                    td=$("<td>"+data[i][key].toFixed(4)+"</td>");
                }else{
                    td=$("<td>"+data[i][key]+"</td>");
                }
                tr.append(td);
            })
            tbody.append(tr);
        }

        $('#table').css('display','block')
    }


    $.plotCandle = function(candleData){
        var upColor = '#ec0000';
        var upBorderColor = '#8A0000';
        var downColor = '#00da3c';
        var downBorderColor = '#008F28';
        var candleChart= echarts.init(document.getElementById('echart_candle'));
        var rawData=candleData.data;
        var categoryData = [];
        var values = [];
        for (var i = 0; i < rawData.length; i++) {
            categoryData.push(rawData[i].splice(0, 1)[0]);
            values.push(rawData[i])
        }
        candleOption = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                }
            },
            legend: {
                data:[ticker]
            },
            xAxis: {
                type: 'category',
                data: categoryData,
                scale: true,
                boundaryGap : false,
                axisLine: {onZero: false},
                splitLine: {show: false},
                splitNumber: 20,
                min: 'dataMin',
                max: 'dataMax'
            },
            yAxis: {
                scale: true,
                splitArea: {
                    show: true
                }
            },
            dataZoom: [
            {
                type: 'inside',
                start: 50,
                end: 100
            },
            {
                show: true,
                type: 'slider',
                y: '90%',
                start: 50,
                end: 100
            }
            ],
            series: [
            {
                name: ticker,
                type: 'candlestick',
                data: values,
                itemStyle: {
                    normal: {
                        color: upColor,
                        color0: downColor,
                        borderColor: upBorderColor,
                        borderColor0: downBorderColor
                    }
                },
            },

            ]
        };
        candleChart.setOption(candleOption);


    }


    $.plotLine = function(lineData){
        console.log("test");
        var legend=lineData.columns.splice(1,3);
        var lineChart= echarts.init(document.getElementById('echart_line'));
        var strategies=[];
        var dates=[];
        var mySeries=[];

        ticker = "";
        result=lineData.data;
        result.splice(0,1);

        for(var n=0;n<result.length;n++){
            dates[n]=result[n][0];
        }

        for(var m=0;m<result[0].length-1;m++){
            strategies[m]=[];
        }

        for(var i=0;i<result.length;i++){
            for(var k=0;k<legend.length;k++){
                strategies[k][i]=result[i][k+1];
            }
        }

        for(var j=0;j<legend.length;j++){
            var temp={};
            temp.name=legend[j];
            temp.type="line";
            temp.data=strategies[j]

            mySeries.push(temp);
        }
//        max1 = Math.max(...market);
//        max2 = Math.max(...strategy);
//        min1 = Math.min(...market);
//        min2 = Math.min(...strategy);
//
//        maxY = max1>max2?max1:max2;
//        minY = min1<min2?min1:min2;

        lineOption = {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data:legend
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: dates
            },
            yAxis: {
                type: 'value',
//                min: minY - 0.1,
//                max: maxY + 0.1,
            },
            dataZoom:[
                {
                    type: 'slider',
                    show: true,
                    xAxisIndex: [0],
                },
                {
                    type: 'inside',
                    xAxisIndex: [0],

                },
            ],
            series: mySeries
        };
        lineChart.setOption(lineOption);




    }
  })